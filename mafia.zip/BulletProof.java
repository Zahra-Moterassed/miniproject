public class BulletProof extends Player{
    boolean isOnceDead=false;
    public BulletProof(String name, Role role) {
        super(name, role);
    }
}
