public enum Role {
    Joker,villager,detective,doctor,bulletproof,mafia,godfather,silencer
}
