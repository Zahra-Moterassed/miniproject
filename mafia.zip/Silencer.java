public class Silencer extends Player{
    public Silencer(String name, Role role) {
        super(name, role);
    }

}
